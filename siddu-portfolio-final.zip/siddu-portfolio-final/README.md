# Vakiti Siddu — Portfolio Website

A modern, responsive personal portfolio website built with pure HTML, CSS, and JavaScript.
Dark glassmorphism theme with purple/blue gradients, smooth animations, and 5 sections.

**Stack focus:** Angular, TypeScript, JavaScript, Java, SQL/MySQL (matches latest resume).

---

## 📁 Project Structure

```
siddu-portfolio/
│
├── index.html              ← Main HTML file (all pages are sections in one file)
│
├── css/
│   └── style.css           ← All styles: theme tokens, layout, components, responsive
│
├── js/
│   └── main.js             ← All interactivity: theme toggle, animations, tabs, form
│
└── README.md               ← This file
```

---

## 🚀 How to Run

**Option 1 — Open locally (recommended for quick preview):**
Use the standalone single-file version (CSS + JS inlined) — just double-click it.

**Option 2 — Live server (VS Code) for the multi-file version:**
Install the "Live Server" extension → Right-click `index.html` → Open with Live Server
(Required because browsers block relative file:// loading of external CSS/JS files.)

**Option 3 — Deploy free online:**
- **GitHub Pages:** Push to a repo → Settings → Pages → Deploy from main branch
- **Netlify:** Drag the folder into netlify.com/drop
- **Vercel:** Run `vercel` in terminal or drag folder to vercel.com

---

## 🛠️ Tech Stack

| Layer       | Technology                        |
|-------------|-----------------------------------|
| Markup      | HTML5 (semantic)                  |
| Styling     | CSS3 (custom properties, Grid, Flexbox, animations) |
| Scripting   | Vanilla JavaScript (ES6+)         |
| Fonts       | Google Fonts — Syne + DM Sans     |
| Icons       | Font Awesome 6 (CDN)              |
| No build    | Zero dependencies, no npm needed  |

---

## 📦 Featured Projects (synced with resume)

1. **Luxury Fashion E-Commerce Web App** — HTML5, CSS3, JavaScript, Flexbox, CSS Grid
2. **Personal Portfolio Website** — HTML5, CSS3, JavaScript, Responsive Design
3. **Memory Game (Pokémon Edition)** — HTML5, CSS3, JavaScript, DOM Manipulation
4. **JPMorganChase Software Engineering Simulation** — Java, Spring Boot, Kafka, REST APIs, H2 DB

---

## ✨ Features

- ✅ Dark / Light mode toggle (persists via localStorage)
- ✅ Smooth scroll-triggered fade-up animations (IntersectionObserver)
- ✅ Animated skill progress bars
- ✅ Filterable skill categories (Frontend / Backend / CS / Tools)
- ✅ Featured project cards with tech pills
- ✅ Responsive mobile menu (hamburger) with body-scroll lock
- ✅ Glassmorphism cards with backdrop-filter blur
- ✅ Contact form with validation + success state
- ✅ Active nav highlight based on scroll position
- ✅ Ambient orb backgrounds + noise texture overlay
- ✅ Gradient text, gradient ring avatar
- ✅ Fully responsive (mobile, tablet, desktop) — 4 breakpoints + touch-device optimizations

---

## 📱 Mobile-Friendliness Checklist

- Hamburger menu with full-screen overlay on screens ≤768px
- Body scroll locked while mobile menu is open
- All grids collapse to single column on small screens
- Font sizes use `clamp()` for fluid scaling
- Form inputs set to `font-size: 1rem` to prevent iOS auto-zoom
- Touch targets enlarged (44px+) on touch devices via `hover: none` media query
- Hover effects disabled on touch devices (no sticky hover states)
- IntersectionObserver thresholds lowered on mobile so animations trigger reliably

---

## 📝 Customisation Guide

### Update your resume link
Search for `drive.google.com` in `index.html` — replace all 3 occurrences with your new link.

### Add a real profile photo
In `index.html`, find `.avatar-inner` and replace the text `VS` with:
```html
<img src="assets/images/your-photo.jpg" alt="Vakiti Siddu" style="width:100%;height:100%;object-fit:cover;" />
```

### Add a new project
Copy any `.project-card` block in `index.html` and update the title, description, tech pills, and GitHub link.

### Change the colour theme
In `css/style.css`, edit the `:root` block:
```css
--accent1: #7c3aed;   /* Primary purple */
--accent2: #3b82f6;   /* Blue */
--accent3: #a78bfa;   /* Light purple */
```

### Connect the contact form to a real email
In `js/main.js`, find the comment `/* Simulate network delay */` and replace the `setTimeout`
with an EmailJS or Formspree API call.

---

## 📬 Contact

**Vakiti Siddu**
- Email: siddumudiraj789@gmail.com
- GitHub: github.com/siddumudhiraj
- LinkedIn: linkedin.com/in/siddu-mudhiraj-440a23300
- LeetCode: leetcode.com/u/M8e2oyQW9s
